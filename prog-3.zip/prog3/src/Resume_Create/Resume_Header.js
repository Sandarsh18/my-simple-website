import React from "react";

class Resume_Header extends React.Component {
  render() {
    return (
      <header className="resume-header">
        <h1>Resume Details</h1>
      </header>
    );
  }
}

export default Resume_Header;
