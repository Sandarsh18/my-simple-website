import React from "react";

class Resume_Person_Info extends React.Component {
  render() {
    return (
      <div className="person-info">
        <div><strong>Name:</strong> <p>Sandarsh</p></div>
        <div><strong>Address:</strong> <p>Konan gunte, Bengaluru</p></div>
        <div><strong>Phone No:</strong> <p>1234567890</p></div>
        <div><strong>Email ID:</strong> <p>sandarsh@rvce.edu.in</p></div>
      </div>
    );
  }
}

export default Resume_Person_Info;
