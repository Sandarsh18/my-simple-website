import React from "react";
import "./index.css";

class RegistrationForm extends React.Component {
  constructor() {
    super();
    this.state = {
      name: "",
      email: "",
      password: "",
      errors: {},
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // ✅ Validation function using Regular Expressions
  validate() {
    const errors = {};

    // Name validation
    if (!this.state.name) {
      errors.name = "Name is required";
    } else if (this.state.name.length < 3) {
      errors.name = "Name must be at least 3 letters";
    }

    // Email validation using regex
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!this.state.email) {
      errors.email = "Email is required";
    } else if (!emailPattern.test(this.state.email)) {
      errors.email = "Email is invalid";
    }

    // Password validation using regex
    // Minimum 8 characters, at least 1 uppercase, 1 lowercase, 1 number
    const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (!this.state.password) {
      errors.password = "Password is required";
    } else if (!passwordPattern.test(this.state.password)) {
      errors.password =
        "Password must be 8+ chars with uppercase, lowercase & number";
    }

    this.setState({ errors });
    return Object.keys(errors).length === 0;
  }

  // ✅ Handles input changes dynamically
  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  // ✅ Form submission logic
  handleSubmit(e) {
    e.preventDefault();
    if (this.validate()) {
      alert("✅ Form submitted successfully!");
      this.setState({ name: "", email: "", password: "", errors: {} });
    }
  }

  render() {
    const { name, email, password, errors } = this.state;

    return (
      <div className="form-container">
        <h1>Registration Form</h1>
        <form onSubmit={this.handleSubmit}>
          <label>Name:</label>
          <input
            name="name"
            placeholder="Enter your name"
            value={name}
            onChange={this.handleChange}
          />
          <div className="error">{errors.name}</div>

          <label>Email:</label>
          <input
            name="email"
            placeholder="Enter your email"
            value={email}
            onChange={this.handleChange}
          />
          <div className="error">{errors.email}</div>

          <label>Password:</label>
          <input
            name="password"
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={this.handleChange}
          />
          <div className="error">{errors.password}</div>

          <button type="submit">Register</button>
        </form>
      </div>
    );
  }
}

export default RegistrationForm;
