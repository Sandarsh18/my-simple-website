import React from "react";
import "./index.css";

class RegistrationForm extends React.Component {
  constructor() {
    super();
    this.state = {
      name: "",
      username: "",
      email: "",
      phone: "",
      password: "",
      confirmPassword: "",
      age: "",
      gender: "",
      errors: {},
    };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // ✅ Validation Function (Regex-based)
  validate() {
    const errors = {};

    // Name
    if (!this.state.name) {
      errors.name = "Full Name is required";
    } else if (this.state.name.length < 3) {
      errors.name = "Full Name must be at least 3 letters";
    }

    // Username
    const usernamePattern = /^[A-Za-z0-9_]{3,15}$/;
    if (!this.state.username) {
      errors.username = "Username is required";
    } else if (!usernamePattern.test(this.state.username)) {
      errors.username = "Username must be 3–15 characters (letters, numbers, underscores)";
    }

    // Email
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!this.state.email) {
      errors.email = "Email is required";
    } else if (!emailPattern.test(this.state.email)) {
      errors.email = "Email format is invalid";
    }

    // Phone
    const phonePattern = /^[6-9]\d{9}$/;
    if (!this.state.phone) {
      errors.phone = "Phone number is required";
    } else if (!phonePattern.test(this.state.phone)) {
      errors.phone = "Enter a valid 10-digit Indian phone number";
    }

    // Age
    if (!this.state.age) {
      errors.age = "Age is required";
    } else if (this.state.age < 18 || this.state.age > 60) {
      errors.age = "Age must be between 18 and 60";
    }

    // Gender
    if (!this.state.gender) {
      errors.gender = "Gender is required";
    }

    // Password
    const passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
    if (!this.state.password) {
      errors.password = "Password is required";
    } else if (!passwordPattern.test(this.state.password)) {
      errors.password =
        "Password must be 8+ chars with uppercase, lowercase & number";
    }

    // Confirm Password
    if (this.state.confirmPassword !== this.state.password) {
      errors.confirmPassword = "Passwords do not match";
    }

    this.setState({ errors });
    return Object.keys(errors).length === 0;
  }

  // ✅ Handles input change
  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  // ✅ Submit handler
  handleSubmit(e) {
    e.preventDefault();
    if (this.validate()) {
      alert(`✅ Registration Successful!
Welcome, ${this.state.name}!`);

      this.setState({
        name: "",
        username: "",
        email: "",
        phone: "",
        password: "",
        confirmPassword: "",
        age: "",
        gender: "",
        errors: {},
      });
    }
  }

  render() {
    const {
      name,
      username,
      email,
      phone,
      password,
      confirmPassword,
      age,
      gender,
      errors,
    } = this.state;

    return (
      <div className="form-container">
        <h1>User Registration Form</h1>
        <form onSubmit={this.handleSubmit}>
          <label>Full Name:</label>
          <input
            name="name"
            placeholder="Enter your full name"
            value={name}
            onChange={this.handleChange}
          />
          <div className="error">{errors.name}</div>

          <label>Username:</label>
          <input
            name="username"
            placeholder="Choose a username"
            value={username}
            onChange={this.handleChange}
          />
          <div className="error">{errors.username}</div>

          <label>Email:</label>
          <input
            name="email"
            placeholder="Enter your email"
            value={email}
            onChange={this.handleChange}
          />
          <div className="error">{errors.email}</div>

          <label>Phone Number:</label>
          <input
            name="phone"
            placeholder="Enter your phone number"
            value={phone}
            onChange={this.handleChange}
          />
          <div className="error">{errors.phone}</div>

          <label>Age:</label>
          <input
            type="number"
            name="age"
            placeholder="Enter your age"
            value={age}
            onChange={this.handleChange}
          />
          <div className="error">{errors.age}</div>

          <label>Gender:</label>
          <select name="gender" value={gender} onChange={this.handleChange}>
            <option value="">--Select--</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
          <div className="error">{errors.gender}</div>

          <label>Password:</label>
          <input
            name="password"
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={this.handleChange}
          />
          <div className="error">{errors.password}</div>

          <label>Confirm Password:</label>
          <input
            name="confirmPassword"
            type="password"
            placeholder="Re-enter password"
            value={confirmPassword}
            onChange={this.handleChange}
          />
          <div className="error">{errors.confirmPassword}</div>

          <button type="submit">Register</button>
        </form>
      </div>
    );
  }
}

export default RegistrationForm;
