import React from "react";

// Initial student data
const studlist = [
  { slno: 1, name: "Stud1", usn: "RVCE01", age: 20, dept: "CSE", sem: "5", gender: "Male", tmarks: 150, grade: "A" },
  { slno: 2, name: "Stud2", usn: "RVCE02", age: 21, dept: "ECE", sem: "6", gender: "Female", tmarks: 140, grade: "B" },
];

// 🔹 Component to display one row of student data
class StudentRow extends React.Component {
  render() {
    const s = this.props.stdli;
    return (
      <tr>
        <td>{s.slno}</td>
        <td>{s.name}</td>
        <td>{s.usn}</td>
        <td>{s.age}</td>
        <td>{s.gender}</td>
        <td>{s.dept}</td>
        <td>{s.sem}</td>
        <td>{s.tmarks}</td>
        <td>{s.grade}</td>
      </tr>
    );
  }
}

// 🔹 Component to render table of students
class StudentsTable extends React.Component {
  render() {
    const studrows = this.props.studlist.map((studli) => (
      <StudentRow key={studli.slno} stdli={studli} />
    ));

    return (
      <table border="1" width="100%">
        <thead>
          <tr>
            <th>Sl No</th>
            <th>Name</th>
            <th>USN</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Department</th>
            <th>Semester</th>
            <th>Total Marks</th>
            <th>Grade</th>
          </tr>
        </thead>
        <tbody>{studrows}</tbody>
      </table>
    );
  }
}

// 🔹 Component for adding new student
class StudentAddSubmit extends React.Component {
  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  // Grade calculation based on marks
  calculateGrade(marks) {
    if (marks >= 150) return "A+";
    if (marks >= 120) return "A";
    if (marks >= 100) return "B";
    if (marks >= 80) return "C";
    return "F";
  }

  handleSubmit(e) {
    e.preventDefault();
    const form = document.forms.studAdd;

    const studli = {
      name: form.name.value,
      usn: form.usn.value,
      age: form.age.value,
      gender: form.gender.value,
      dept: form.dept.value,
      sem: form.sem.value,
      tmarks: Number(form.tmarks.value),
      grade: this.calculateGrade(Number(form.tmarks.value)),
    };

    this.props.CreateStudentAdd(studli);
    form.reset();
  }

  render() {
    return (
      <form name="studAdd" onSubmit={this.handleSubmit}>
        <input type="text" name="name" placeholder="Name" required />
        <input type="text" name="usn" placeholder="USN" required />
        <input type="number" name="age" placeholder="Age" min="18" max="25" required />
        <select name="gender" required>
          <option value="">Gender</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
        <select name="dept" required>
          <option value="">Department</option>
          <option value="CSE">CSE</option>
          <option value="ECE">ECE</option>
          <option value="ISE">ISE</option>
          <option value="MECH">MECH</option>
          <option value="CIVIL">CIVIL</option>
        </select>
        <input type="number" name="sem" placeholder="Semester" min="1" max="8" required />
        <input type="number" name="tmarks" placeholder="Total Marks" min="0" max="200" required />
        <button type="submit">Add Student</button>
      </form>
    );
  }
}

// 🔹 Parent Component
class StudentListTable extends React.Component {
  constructor() {
    super();
    this.state = { newStudList: [] };
    this.CreateStudentAdd = this.CreateStudentAdd.bind(this);
  }

  componentDidMount() {
    this.loadData();
  }

  // Simulating loading delay
  loadData() {
    setTimeout(() => {
      this.setState({ newStudList: studlist });
      console.log(" Student data loaded successfully!");
    }, 2000);
  }

  // Add new student
  CreateStudentAdd(studli) {
    const studlength = this.state.newStudList.length + 1;
    studli.slno = studlength;
    const newList = this.state.newStudList.slice();
    newList.push(studli);
    this.setState({ newStudList: newList });
  }

  render() {
    return (
      <>
        <h2> Student Registration Portal</h2>
        <p>Manage student details dynamically using React Components, Props, and State.</p>
        <StudentsTable studlist={this.state.newStudList} />
        <h3>Add a New Student</h3>
        <StudentAddSubmit CreateStudentAdd={this.CreateStudentAdd} />
      </>
    );
  }
}

export default StudentListTable;
